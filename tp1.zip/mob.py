
class Mob:

    def __init__(self, x, y, rad, moveFreq):
        self.x = x
        self.y = y
        self.rad = rad
        self.moveFreq = moveFreq