
def aStar() -> tuple:
    pass

