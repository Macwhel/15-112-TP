
class Mob:

    def __init__(self, x, y, mobType, rad):
        self.x = x
        self.y = y
        self.rad = rad
        self.type = mobType