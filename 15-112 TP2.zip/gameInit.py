
def appStartedHelper(difficulty: int, level: int) -> tuple:
    

    return (numRows, numCols, numOfMobs, mobSpeed, battleMobHealth)