from cmu_112_graphics import *
from graphics import *

if __name__ == "__main__":
    runApp(width = 1000, height = 1000)
